#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <gtk/gtk.h>
#include"nutrisionniste.h"


enum
{	
	EID,
	EJOUR,
	EMOIS,
	EANNEE,
	EAL,
	ETYPE,
	COLUMNS,
};


void Ajouter(Menu menu)
{
    FILE* f;
    f=fopen("menu.txt","a+");
    fprintf(f,"%s %d  %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
    fclose(f);
}
//////////////////////////////////////////////////////////////////
void Supprimer(char id[10],Menu menu)
{
    FILE* f ;
    FILE* f2;
    f=fopen("menu.txt","r");
    f2=fopen("tmp.txt","a+");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id,menu.id)!=0)
                   fprintf(f2,"%s %d  %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
        }
    }
    fclose(f);
    fclose(f2);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}
////////////////////////////////////////////////////////////////////////////
void Modifier(char id[10],Menu menu)
{
    FILE* f ;
    FILE* f2;
    f=fopen("menu.txt","r+");
    f2=fopen("tmp.txt","a+");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id,menu.id)==0)
                {
		   fprintf(f2,"%s %d %d %d %s %s ",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
    
		}
		else
		    fprintf(f2,"%s %d %d %d %s %s ",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
        }
    }
    fclose(f);
    fclose(f2);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}
//////////////////////////////////////////////////////////////////////////////
void Chercher(char id[10],Menu menu)
{
    
    FILE* f ;
    int rech=0;
    f=fopen("menu.txt","r");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id,menu.id)==0)
		{
		       rech=1;
		}
        }
    }
    fclose(f);
    if (rech==0)
    printf("Impossible de trouver cet stock\n");
}
////////////////////////////////////////////////////////////////////////////
void Afficher(GtkWidget *liste,char ch[50])
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter   iter; 
	GtkListStore  *store;
	FILE *f;
	store=NULL;
	Menu menu;
	store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" aliment",renderer,"text",EAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen(ch,"r");
if(f==NULL)
{
return;
}
else
{
	f=fopen(ch,"a+");
	while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EID,menu.id,EJOUR,&menu.date.jour,EMOIS,&menu.date.mois,EANNEE,&menu.date.annee,EAL,menu.aliment,ETYPE,menu.type,-1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
        

}

