#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "stock.h"

void
on_Add_stock_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *ajout;
	ajout=create_Ajouter_stock();
	gtk_widget_show(ajout);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock");
	gtk_widget_destroy(affiche);
}



void
on_supprimer_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *supp;
	supp=create_supprimer_stock();
	gtk_widget_show(supp);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock");
	gtk_widget_destroy(affiche);
}


void
on_modify_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *modif;
	modif=create_modifier_stock();
	gtk_widget_show(modif);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock");
	gtk_widget_destroy(affiche);
}


void
on_add_ajout_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry;
	char id[20];
	entry=lookup_widget(button,"entry_id_stock");
	strcpy(id,gtk_entry_get_text(entry));
	
         
        GtkWidget  *combo_type_stock;
        char  type [20];
        combo_type_stock=lookup_widget( button,"combo_type_stock");
        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type_stock)));
         
       GtkWidget  *entry_name_stock;
        char  name [20];
        entry_name_stock=lookup_widget( button,"entry_name_stock");
        strcpy(name,gtk_entry_get_text(entry_name_stock));
     
       GtkWidget  *combobox_quality_stock;
        char  quality [20];
        combobox_quality_stock=lookup_widget( button,"combobox_quality_stock");
        strcpy(quality,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_quality_stock)));
       
       GtkWidget  *spin_stock;
       int stock;
       spin_stock=lookup_widget( button,"spin_stock");
       stock=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin_stock));
      
       
        GtkWidget  *calendar_stock1;
	int annee,mois,jour;
       calendar_stock1=lookup_widget( button,"calendar_stock1");
       gtk_calendar_get_date(calendar_stock1,&annee,&mois,&jour);

       GtkWidget  *calendar_stock2;
	int annee2,mois2,jour2;
       calendar_stock2=lookup_widget( button,"calendar_stock2");
       gtk_calendar_get_date(calendar_stock2,&annee2,&mois2,&jour2);
       
	//g_print("id=%s , type=%s , name=%s , quality=%s , stock=%d , calendrier_achat=%d/%d/%d , calendrier_exp=%d/%d/%d",id,type,name,quality,stock,jour,mois,annee,jour2,mois2,annee2);
	struct stockage st;
	strcpy(st.id,id);
	strcpy(st.nom,name);
	strcpy(st.type,type);
	strcpy(st.quality,quality);
	st.quantite=stock;
	st.quantite_restante=stock;
	st.date_achat.jour=jour;
	st.date_achat.mois=mois;
	st.date_achat.annee=annee;
	st.date_expiration.jour=jour2;
	st.date_expiration.mois=mois2;
	st.date_expiration.annee=annee2;
	ajout_stock(st);
	on_Cancel_ajout_stock_clicked(button,user_data);
}


void
on_Cancel_ajout_stock_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=create_Affichage_stock();
	gtk_widget_show(affiche);

	GtkWidget *ajout;
	ajout=lookup_widget(button,"Ajouter_stock");
	gtk_widget_destroy(ajout);
}


void
on_modif_modifier_stock_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry_id_stock;
	char id[20];
	entry_id_stock=lookup_widget(button,"entry_id_stock2");
	strcpy(id,gtk_entry_get_text(entry_id_stock));
	
         
        GtkWidget  *combo_type_stock;
        char  type [20];
        combo_type_stock=lookup_widget( button,"combo_type_stock2");
        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type_stock)));
         
       GtkWidget  *entry_name_stock;
        char  name [20];
        entry_name_stock=lookup_widget( button,"entry_name_stock2");
        strcpy(name,gtk_entry_get_text(entry_name_stock));
     
       GtkWidget  *combobox_quality_stock1;
        char  quality [20];
        combobox_quality_stock1=lookup_widget( button,"combobox_quality_stock1");
        strcpy(quality,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_quality_stock1)));
       
       GtkWidget  *spin_stock;
       int stock;
       spin_stock=lookup_widget( button,"spin_stock2");
       stock=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin_stock));
      
       
        GtkWidget  *calendar_stock1;
	int annee,mois,jour;
       calendar_stock1=lookup_widget( button,"calendar_stock3");
       gtk_calendar_get_date(calendar_stock1,&annee,&mois,&jour);

       GtkWidget  *calendar_stock2;
	int annee2,mois2,jour2;
       calendar_stock2=lookup_widget( button,"calendar_stock4");
       gtk_calendar_get_date(calendar_stock2,&annee2,&mois2,&jour2);
       
        struct stockage st;
	strcpy(st.id,id);
	strcpy(st.nom,name);
	strcpy(st.type,type);
	strcpy(st.quality,quality);
	st.quantite=stock;
	st.quantite_restante=stock;
	st.date_achat.jour=jour;
	st.date_achat.mois=mois;
	st.date_achat.annee=annee;
	st.date_expiration.jour=jour2;
	st.date_expiration.mois=mois2;
	st.date_expiration.annee=annee2;
	Modifier_Stock(st);
}


void
on_Cancel_modifier_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=create_Affichage_stock();
	gtk_widget_show(affiche);

	GtkWidget *modif;
	modif=lookup_widget(button,"modifier_stock");
	gtk_widget_destroy(modif);
}


void
on_supprimer_stock2_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry_id_stock;
	char id[20];
	entry_id_stock=lookup_widget(button,"entry_id_stock3");
	strcpy(id,gtk_entry_get_text(entry_id_stock));
	Supprimer_Stock(id);
}


void
on_Cancel_supprimer_stock_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=create_Affichage_stock();
	gtk_widget_show(affiche);

	GtkWidget *supp;
	supp=lookup_widget(button,"suppriemr_stock");
	gtk_widget_destroy(supp);
}


void
on_actualiser_stock_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview_stock");
	Afficher_stock(treeview);
}


void
on_Actualiser_stock2_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview_stock2");
	Afficher_stock(treeview);
}


void
on_Alert_stock_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affi;
	affi=create_Affichage_alert_stock();
	gtk_widget_show(affi);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock_admin");
	gtk_widget_destroy(affiche);
}


void
on_Actualiser_stock3_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview_stock3");
	Afficher_alert_stock(treeview);
}


void
on_Cancel_stock10_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affi;
	affi=create_Affichage_stock_admin();
	gtk_widget_show(affi);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_alert_stock");
	gtk_widget_destroy(affiche);
}

