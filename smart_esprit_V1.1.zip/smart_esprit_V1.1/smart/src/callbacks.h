#include <gtk/gtk.h>
typedef struct 
{

int mois ;
int jour ;
int annee;
}Date;
typedef struct stockage
{
char id[20];
char nom[20];
char type [20];
int quantite ;
Date date_achat;
Date date_expiration;
char quality [20];
int quantite_restante;
}stockage ;

void
on_Add_stock_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modify_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_add_ajout_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_ajout_stock_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_modifier_stock_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_modifier_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_stock2_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_supprimer_stock_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_stock_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualiser_stock2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Alert_stock_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualiser_stock3_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_stock10_clicked              (GtkButton       *button,
                                        gpointer         user_data);
