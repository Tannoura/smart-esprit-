#include "callbacks.h"
#include "stock.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
void ajout_stock(stockage stock)
{
    FILE* f;
   
    f=fopen("stock.txt","a+");
    if (f==EOF){
        return;
    }
    else
    {
    	fprintf(f,"%s %s %s %d %d/%d/%d %d/%d/%d %s %d\n", stock.id,stock.nom,stock.type,stock.quantite,stock.date_achat.jour,stock.date_achat.mois,stock.date_achat.annee,stock.date_expiration.jour,stock.date_expiration.mois,stock.date_expiration.annee,stock.quality,stock.quantite_restante);
    
    }   
    fclose(f);
}
void Modifier_Stock(stockage st)
{
struct stockage stock;
    FILE* f ;
    FILE* f2;
     char date_achat[20],date_expiration[20];
   
    f=fopen("stock.txt","r+");
    f2=fopen("tmp.txt","a+");
    if (f==EOF)
        printf("pas de Stock pour modifier\n");
    else
    {
        while (fscanf(f,"%s %s %s %d %s %s %s %d\n", stock.id,stock.nom,stock.type,&stock.quantite,date_achat,date_expiration,stock.quality,&stock.quantite_restante)!=EOF)
        {
                if (strcmp(st.id,stock.id)==0)
                {
		    fprintf(f2,"%s %s %s %d %d/%d/%d %d/%d/%d %s %d\n", st.id,st.nom,st.type,st.quantite,st.date_achat.jour,st.date_achat.mois,st.date_achat.annee,st.date_expiration.jour,st.date_expiration.mois,st.date_expiration.annee,st.quality,st.quantite_restante);
    
		}
		else
		    fprintf(f2,"%s %s %s %d %s %s %s %d\n",stock.id,stock.nom,stock.type,stock.quantite,date_achat,date_expiration,stock.quality,stock.quantite_restante);
        }
    }
    fclose(f);
    fclose(f2);
    remove("stock.txt");
    rename("tmp.txt","stock.txt");
}
void Supprimer_Stock(char id[20])
{
    FILE* f ;
    FILE* f2;
     char date_achat[20],date_expiration[20];
    f=fopen("stock.txt","r");
    f2=fopen("tmp.txt","a+");
struct stockage stock;
    if (f==EOF)
        printf("pas de Stock pour supprimer\n");
    else
    {
        while (fscanf(f,"%s %s %s %d %s %s %s %d\n", stock.id,stock.nom,stock.type,&stock.quantite,date_achat,date_expiration,stock.quality,&stock.quantite_restante)!=EOF)
        {
                if (strcmp(id,stock.id)!=0)
                   fprintf(f2,"%s %s %s %d %s %s %s %d\n",stock.id,stock.nom,stock.type,stock.quantite,date_achat,date_expiration,stock.quality,stock.quantite_restante);
        }
    }
    fclose(f);
    fclose(f2);
    remove("stock.txt");
    rename("tmp.txt","stock.txt");
}
void Afficher_stock(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;
	char date_achat[20];
	char date_expiration[20];


store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
 	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Id",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Produit",renderer, "text",PRODUIT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Type",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Quantite",renderer, "text",QUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Qualite",renderer, "text",QUALITE,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date achat",renderer, "text",DATE1,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date expiration",renderer, "text",DATE2,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Quantite restante",renderer, "text",QUANTITE_RESTANT,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);

f = fopen("stock.txt","r");
if(f==NULL)
{
return;
}
else
{
 	f=fopen("stock.txt","a+");
	struct stockage stock ;
	while(fscanf(f,"%s %s %s %d %s %s %s %d\n", stock.id,stock.nom,stock.type,&stock.quantite,date_achat,date_expiration,stock.quality,&stock.quantite_restante)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,ID,stock.id,PRODUIT,stock.nom,TYPE,stock.type,QUANTITE,stock.quantite,QUALITE,stock.quality,DATE1,date_achat,DATE2,date_expiration,QUANTITE_RESTANT,stock.quantite_restante,-1);
	}
	fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
}
}


void Afficher_alert_stock(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;
	char date_achat[20];
	char date_expiration[20];


store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
 	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Id",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Produit",renderer, "text",PRODUIT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Type",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Quantite",renderer, "text",QUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Qualite",renderer, "text",QUALITE,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date achat",renderer, "text",DATE1,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Date expiration",renderer, "text",DATE2,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" Quantite restante",renderer, "text",QUANTITE_RESTANT,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);

f = fopen("stock.txt","r");
if(f==NULL)
{
return;
}
else
{
 	f=fopen("stock.txt","a+");
	struct stockage stock ;
	while(fscanf(f,"%s %s %s %d %s %s %s %d\n", stock.id,stock.nom,stock.type,&stock.quantite,date_achat,date_expiration,stock.quality,&stock.quantite_restante)!=EOF)
	{
		if (stock.quantite_restante==0){
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,ID,stock.id,PRODUIT,stock.nom,TYPE,stock.type,QUANTITE,stock.quantite,QUALITE,stock.quality,DATE1,date_achat,DATE2,date_expiration,QUANTITE_RESTANT,stock.quantite_restante,-1);
	}	
	}
	fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
}
}
















