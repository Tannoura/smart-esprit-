#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "etudiant.h"
#include "stock.h"
#include "header.h"
#include"nutrisionniste.h"
#include "fonction.h"
#include "temperature.h"
void
on_button1_login_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{	
	
	GtkWidget* window1;
	GtkWidget* window;
	GtkWidget *entry1,*entry2;
	entry1=lookup_widget(button,"entry1_login");
	entry2=lookup_widget(button,"entry2_login");
	char ch1[20];
	char ch2[20];
	if (gtk_entry_get_text(entry1)!="" & gtk_entry_get_text(entry2)!=""){
		strcpy(ch1,gtk_entry_get_text(entry1));
		strcpy(ch2,gtk_entry_get_text(entry2));
		if (strcmp(ch1,"hama")==0 & strcmp(ch2,"1234")==0){
				window1=create_page_accueil();
				gtk_widget_show(window1);
				
				window=lookup_widget(button,"Login");
				gtk_widget_destroy(window);}
		
		
	}
}

void
on_button4_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_affiche();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"page_accueil");
	gtk_widget_destroy(window);
}

char leveel[20];
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void
on_addReturn_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* addetudiant;
addetudiant = lookup_widget(objet_graphique, "Addetudiant");
gtk_widget_destroy(addetudiant);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);

}


void
on_SUBMIT_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* input;
etudiant e;

input = lookup_widget(objet_graphique, "entryCIN") ;
strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryFIRSTNAME") ;
strcpy(e.firstname,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryLASTNAME") ;
strcpy(e.lastname,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryADRESS") ;
strcpy(e.adress,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryPHONE") ;
strcpy(e.phone,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryEMAIL") ;
strcpy(e.level,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryPASSWORD") ;
strcpy(e.password,gtk_entry_get_text(GTK_ENTRY(input)));


add_etudiant(e);
}
void
on_delete_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget* affiche;
GtkWidget* DELETE;
DELETE = lookup_widget(objet_graphique, "DELETE");
gtk_widget_destroy(DELETE);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);

}



void
on_update_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* UPDATEetudiant;
UPDATEetudiant = lookup_widget(objet_graphique, "UPDATEetudiant");
gtk_widget_destroy(UPDATEetudiant);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);
}



void
on_buttonUPD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

  GtkWidget* input;
  etudiant e1;

  input = lookup_widget(objet_graphique, "entryCIN") ;
  strcpy(e1.cin,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryFIRSTNAME") ;
  strcpy(e1.firstname,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryLASTNAME") ;
  strcpy(e1.lastname,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryADRESS") ;
  strcpy(e1.adress,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryPHONE") ;
  strcpy(e1.phone,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryEMAIL") ;
  strcpy(e1.level,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryPASSWORD") ;
  strcpy(e1.password,gtk_entry_get_text(GTK_ENTRY(input)));

  upd_etudiant(e1);
}



void
on_buttonADD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* addetudiant;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
addetudiant = lookup_widget(objet_graphique, "Addetudiant");
addetudiant = create_Addetudiant();
gtk_widget_show(addetudiant);

}


void
on_buttonUPDATE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* UPDATEetudiant;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
UPDATEetudiant = lookup_widget(objet_graphique, "UPDATEetudiant");
UPDATEetudiant = create_UPDATEetudiant();
gtk_widget_show(UPDATEetudiant);

}


void
on_buttonDLT_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* DELETE;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
DELETE = lookup_widget(objet_graphique, "DELETE");
DELETE = create_DELETE();
gtk_widget_show(DELETE);

}


void
on_buttonaffiche_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)


{
GtkWidget *affiche;
GtkWidget *treeview1;
affiche = lookup_widget(objet_graphique,"affiche");

treeview1 = lookup_widget(affiche,"treeview1_etudiant");
aff_etudiant(treeview1,"db_etudiant.txt");
}







void
on_buttonDELETE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* input;
  char cin[50];
  input = lookup_widget(objet_graphique, "entryCIN") ;
  strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
  if (check_etudiant(cin)==1){
    del_etudiant(cin);
}

}


void
on_buttonNBRE_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget* affiche;
  GtkWidget* nbretudiant;
  affiche = lookup_widget(objet_graphique, "affiche");
  gtk_widget_destroy(affiche);
  nbretudiant = lookup_widget(objet_graphique, "nbretudiant");
  nbretudiant = create_nbretudiant();
  gtk_widget_show(nbretudiant);
}


void
on_returnb_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget* affiche;
  GtkWidget* nbretudiant;
  nbretudiant = lookup_widget(objet_graphique, "nbretudiant");
  gtk_widget_destroy(nbretudiant);
  affiche = lookup_widget(objet_graphique, "affiche");
  affiche = create_affiche();
  gtk_widget_show(affiche);
}






void
on_NB2_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NB2,*l;
GdkColor color;	
 char ch[40];
 NB2 =lookup_widget(objet, "NB2" );
 int k=NBRE2();
 l=lookup_widget(objet,"label36_etudiant");
 sprintf(ch,"Le nombre de level2 est %d",k);
 gtk_label_set_text(GTK_LABEL(l),ch);

 gdk_color_parse("blue",&color);
 gtk_widget_modify_fg(l,GTK_STATE_NORMAL,&color);
}


void
on_NB1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{

GdkColor color;
GtkWidget *NB1,*l;
int k;
	
 char ch[40];
 NB1 =lookup_widget(objet, "NB1" );
 k=NBRE1();

 l=lookup_widget(objet,"label26_etudiant");
 
sprintf(ch,"Le nombre de level1 est %d",k);
 gtk_label_set_text(GTK_LABEL(l),ch); 

 gdk_color_parse("red",&color);
 gtk_widget_modify_fg(l,GTK_STATE_NORMAL,&color);
}






void
on_buttonrecherche_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
char reche[20];
etudiant e;
GtkWidget* treeview2;
GtkWidget* input;
GtkWidget* recherche;


input = lookup_widget(objet_graphique, "entryrecherche") ;
strcpy(reche,gtk_entry_get_text(GTK_ENTRY(input)));
FILE *f=NULL;
FILE *f1=NULL;

f=fopen("db_etudiant.txt","r");
f1=fopen("db_etudiant1.txt","a+");

 while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){
  if (strcmp(reche,e.cin)==0){
       fprintf (f1,"%s %s %s %s %s %s %s \n" ,e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password);
      
 
}
}
fclose(f);
fclose(f1);
recherche = lookup_widget(objet_graphique,"recherche");
treeview2 = lookup_widget(recherche,"treeview2_etudiant");
aff_etudiant(treeview2,"db_etudiant1.txt");   
remove("db_etudiant1.txt");

}


void
on_buttoncheck_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* recherche;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
recherche = lookup_widget(objet_graphique, "recherche");
recherche = create_recherche();
gtk_widget_show(recherche);

}


void
on_returnrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* recherche;
recherche = lookup_widget(objet_graphique, "recherche");
gtk_widget_destroy(recherche);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);
}

void
on_Add_stock_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *ajout;
	ajout=create_Ajouter_stock();
	gtk_widget_show(ajout);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock");
	gtk_widget_destroy(affiche);
}



void
on_supprimer_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *supp;
	supp=create_supprimer_stock();
	gtk_widget_show(supp);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock");
	gtk_widget_destroy(affiche);
}


void
on_modify_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *modif;
	modif=create_modifier_stock();
	gtk_widget_show(modif);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock");
	gtk_widget_destroy(affiche);
}


void
on_add_ajout_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry;
	char id[20];
	entry=lookup_widget(button,"entry_id_stock");
	strcpy(id,gtk_entry_get_text(entry));
	
         
        GtkWidget  *combo_type_stock;
        char  type [20];
        combo_type_stock=lookup_widget( button,"combo_type_stock");
        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type_stock)));
         
       GtkWidget  *entry_name_stock;
        char  name [20];
        entry_name_stock=lookup_widget( button,"entry_name_stock");
        strcpy(name,gtk_entry_get_text(entry_name_stock));
     
       GtkWidget  *combobox_quality_stock;
        char  quality [20];
        combobox_quality_stock=lookup_widget( button,"combobox_quality_stock");
        strcpy(quality,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_quality_stock)));
       
       GtkWidget  *spin_stock;
       int stock;
       spin_stock=lookup_widget( button,"spin_stock");
       stock=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin_stock));
      
       
        GtkWidget  *calendar_stock1;
	int annee,mois,jour;
       calendar_stock1=lookup_widget( button,"calendar_stock1");
       gtk_calendar_get_date(calendar_stock1,&annee,&mois,&jour);

       GtkWidget  *calendar_stock2;
	int annee2,mois2,jour2;
       calendar_stock2=lookup_widget( button,"calendar_stock2");
       gtk_calendar_get_date(calendar_stock2,&annee2,&mois2,&jour2);
       
	//g_print("id=%s , type=%s , name=%s , quality=%s , stock=%d , calendrier_achat=%d/%d/%d , calendrier_exp=%d/%d/%d",id,type,name,quality,stock,jour,mois,annee,jour2,mois2,annee2);
	struct stockage st;
	strcpy(st.id,id);
	strcpy(st.nom,name);
	strcpy(st.type,type);
	strcpy(st.quality,quality);
	st.quantite=stock;
	st.quantite_restante=stock;
	st.date_achat.jour=jour;
	st.date_achat.mois=mois;
	st.date_achat.annee=annee;
	st.date_expiration.jour=jour2;
	st.date_expiration.mois=mois2;
	st.date_expiration.annee=annee2;
	ajout_stock(st);
	on_Cancel_ajout_stock_clicked(button,user_data);
}


void
on_Cancel_ajout_stock_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=create_Affichage_stock();
	gtk_widget_show(affiche);

	GtkWidget *ajout;
	ajout=lookup_widget(button,"Ajouter_stock");
	gtk_widget_destroy(ajout);
}


void
on_modif_modifier_stock_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry_id_stock;
	char id[20];
	entry_id_stock=lookup_widget(button,"entry_id_stock2");
	strcpy(id,gtk_entry_get_text(entry_id_stock));
	
         
        GtkWidget  *combo_type_stock;
        char  type [20];
        combo_type_stock=lookup_widget( button,"combo_type_stock2");
        strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo_type_stock)));
         
       GtkWidget  *entry_name_stock;
        char  name [20];
        entry_name_stock=lookup_widget( button,"entry_name_stock2");
        strcpy(name,gtk_entry_get_text(entry_name_stock));
     
       GtkWidget  *combobox_quality_stock1;
        char  quality [20];
        combobox_quality_stock1=lookup_widget( button,"combobox_quality_stock1");
        strcpy(quality,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_quality_stock1)));
       
       GtkWidget  *spin_stock;
       int stock;
       spin_stock=lookup_widget( button,"spin_stock2");
       stock=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin_stock));
      
       
        GtkWidget  *calendar_stock1;
	int annee,mois,jour;
       calendar_stock1=lookup_widget( button,"calendar_stock3");
       gtk_calendar_get_date(calendar_stock1,&annee,&mois,&jour);

       GtkWidget  *calendar_stock2;
	int annee2,mois2,jour2;
       calendar_stock2=lookup_widget( button,"calendar_stock4");
       gtk_calendar_get_date(calendar_stock2,&annee2,&mois2,&jour2);
       
        struct stockage st;
	strcpy(st.id,id);
	strcpy(st.nom,name);
	strcpy(st.type,type);
	strcpy(st.quality,quality);
	st.quantite=stock;
	st.quantite_restante=stock;
	st.date_achat.jour=jour;
	st.date_achat.mois=mois;
	st.date_achat.annee=annee;
	st.date_expiration.jour=jour2;
	st.date_expiration.mois=mois2;
	st.date_expiration.annee=annee2;
	Modifier_Stock(st);
	on_Cancel_modifier_stock_clicked(button,user_data);
}


void
on_Cancel_modifier_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=create_Affichage_stock();
	gtk_widget_show(affiche);

	GtkWidget *modif;
	modif=lookup_widget(button,"modifier_stock");
	gtk_widget_destroy(modif);
	
}


void
on_supprimer_stock2_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry_id_stock;
	char id[20];
	entry_id_stock=lookup_widget(button,"entry_id_stock3");
	strcpy(id,gtk_entry_get_text(entry_id_stock));
	Supprimer_Stock(id);
	on_Cancel_supprimer_stock_clicked(button,user_data);
}


void
on_Cancel_supprimer_stock_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affiche;
	affiche=create_Affichage_stock();
	gtk_widget_show(affiche);

	GtkWidget *supp;
	supp=lookup_widget(button,"supprimer_stock");
	gtk_widget_destroy(supp);
}


void
on_actualiser_stock_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview_stock");
	Afficher_stock(treeview);
}


void
on_Actualiser_stock2_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview_stock2");
	Afficher_stock(treeview);
}


void
on_Alert_stock_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affi;
	affi=create_Affichage_alert_stock();
	gtk_widget_show(affi);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_stock_admin");
	gtk_widget_destroy(affiche);
}


void
on_Actualiser_stock3_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview_stock3");
	Afficher_alert_stock(treeview);
}


void
on_Cancel_stock10_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affi;
	affi=create_Affichage_stock_admin();
	gtk_widget_show(affi);

	GtkWidget *affiche;
	affiche=lookup_widget(button,"Affichage_alert_stock");
	gtk_widget_destroy(affiche);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_recherche_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	char id[20];
	GtkWidget *entry,*treeview;
	entry=lookup_widget(button,"entry_recherche_stock");
	treeview=lookup_widget(button,"treeview_stock");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry)));
	afficher_stock_rechercher(treeview,id);
}




int x;
int y;
void
on_button_affichage_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *aff,*recla;
aff=create_affichage();
gtk_widget_show(aff);
recla=lookup_widget (objet_graphique,"create_reclamation");
gtk_widget_destroy(recla);

}


void
on_button_add_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajout;
ajout=create_add();
gtk_widget_show(ajout);
}



void
on_button_okk_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
reclamation r ;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*aff;
input1=lookup_widget(objet_graphique,"entry_cin");
if(y==1)
strcpy(r.ref,"1");
else
strcpy(r.ref,"2");

input3=lookup_widget(objet_graphique,"entry_autre");

input4= lookup_widget (objet_graphique , "combobox1_reclamation");
input5= lookup_widget (objet_graphique , "combobox2_reclamation");
input6= lookup_widget (objet_graphique , "combobox3_reclamation");

strcpy(r.CIN,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(r.text_reclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy (r.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy (r.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
strcpy (r.annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
if (x==1)
{
ajout(r);
aff=create_affichage();
gtk_widget_show(aff);
}
}


void
on_button_returnadd_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *reclama;
reclama=create_reclamation();
gtk_widget_show(reclama);
}


void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sup;
sup=create_supprimer_reclamation() ;
gtk_widget_show (sup);
}


void
on_treeview1_reclamation_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	
	gchar* CIN; 
	gchar* ref; 
	gchar* text_reclamation;  
        gchar* jour;
        gchar* mois;
	gchar* annee;
	reclamation r;
	
	FILE *f=NULL;


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{gtk_tree_model_get (GTK_LIST_STORE(model),0,&CIN,1,&ref,2,&text_reclamation,3,&jour,4,&mois,5,&annee,-1);

	strcpy(r.CIN,CIN);
	strcpy(r.ref,ref);
        strcpy(r.text_reclamation,text_reclamation);
	strcpy(r.jour,jour);
        strcpy(r.mois,mois);
        strcpy(r.annee,annee);}

	
        afficher_reclamation(treeview);

}


void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier;
modifier=create_modifier() ;
gtk_widget_show (modifier);
}


void
on_button_sup_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*aff;
char ch[20];
input1=lookup_widget(objet_graphique,"entry_cin");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer(ch);
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_returnsup_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aff;
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_modf_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
reclamation r ;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*affichage,*aff;
input1=lookup_widget(objet_graphique,"entry_cin");
input2=lookup_widget(objet_graphique,"entry_ref");
input3=lookup_widget(objet_graphique,"entry_text");
input4=lookup_widget(objet_graphique,"entry_jour");
input5=lookup_widget(objet_graphique,"entry_mois");
input6=lookup_widget(objet_graphique,"entry_annee");
strcpy(r.CIN,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.ref,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.text_reclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.jour,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(r.mois,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(r.annee,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier(r);
aff=create_affichage();
gtk_widget_show(aff);
}


void
on_button_returnmodif_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aff;
aff=create_affichage();
gtk_widget_show(aff);
}



void
on_button_aff_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
treeview1=lookup_widget(objet_graphique,"treeview1_reclamation");
afficher_reclamation(treeview1);
}


void
on_button_servicereclame_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *service;
service=create_service_();
gtk_widget_show(service);
}


void
on_button_service_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*nb ,*l;
char ch[40];
int k;
k=service_reclamation();
l=lookup_widget(objet,"label4_reclamation");
if (k==1)
{sprintf(ch,"hebergement");}
if (k==2)
{sprintf(ch,"restauration");}
gtk_label_set_text(GTK_LABEL(l),ch);
}




void
on_button_recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry;
	entry=lookup_widget(button,"entry100_reclamation");
	char id[20] ;
	strcpy(id,gtk_entry_get_text(entry));
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview1_reclamation");
	afficher_chercher_reclamation(id,treeview);
}


void
on_button_resultat_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget*nb ,*l,*l1;
char ch[40],ch1[100];
int k;
l1=lookup_widget(objet_graphique,"entry_recherche");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(l1)));
l=lookup_widget(objet_graphique,"label6_reclamation");
k=recherche_reclamation(ch1);
if (k==1)
{sprintf(ch,"existe");}
else
{sprintf(ch,"n'existe pas");}
gtk_label_set_text(GTK_LABEL(l),ch);
}
void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)

{
if(gtk_toggle_button_get_active(togglebutton))
x=1;
else 
x=0;

}





void
on_radiobutton2_reclamation_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y=2;
}


void
on_radiobutton1_reclamation_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y=1;
}



void
on_button3_accueil_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_reclamation();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"page_accueil");
	gtk_widget_destroy(window);
}





void
on_logout_accueil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_Login();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"page_accueil");
	gtk_widget_destroy(window);
}


void
on_retour_reclamation_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_page_accueil();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"reclamation");
	gtk_widget_destroy(window);
}


void
on_retour_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_page_accueil();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"Affichage_stock");
	gtk_widget_destroy(window);
}



void
on_button5_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_Affichage_stock();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"page_accueil");
	gtk_widget_destroy(window);
}




void
on_button2_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_affiche();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"page_accueil");
	gtk_widget_destroy(window);
}


void
on_retour_etudiant_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_page_accueil();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"affiche");
	gtk_widget_destroy(window);
}


void
on_treeview_stock_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	struct stockage stock;
	char date_achat[20];
	gchar *id;
	char date_expiration[20];
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&stock.nom,2,&stock.type,3,&stock.quantite,4,&stock.quality,5,&date_achat,6,&date_expiration,7,&stock.quantite_restante,-1);
g_print("%s",id);
Supprimer_Stock(id);
Afficher_stock(treeview);
}
}


int x;
int y;
char id2[10];


 


void
on_boutonAjouter_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f=NULL;
GtkWidget *ID;
GtkWidget *Al;
GtkWidget *Affichage;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
Menu menu;

char type[100]="PD";

int jour1;
int mois1;
int annee1;
char id1[20];
char al1[20];

if (x==1)
strcpy(type,"PD");
else
if (x==2)
strcpy(type,"Dej");
else 
if (x==3)
strcpy(type,"Din");

jour=lookup_widget(objet_graphique,"jour_menu");
mois=lookup_widget(objet_graphique,"mois_menu");
annee=lookup_widget(objet_graphique,"annee_menu");

ID=lookup_widget(objet_graphique,"entryID");
Al=lookup_widget(objet_graphique,"entryAl");

strcpy(id1,gtk_entry_get_text(GTK_ENTRY(ID)));
strcpy(al1,gtk_entry_get_text(GTK_ENTRY(Al)));

menu.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
menu.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
menu.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

f=fopen("menu.txt","a+");

fprintf(f,"%s %d %d %d %s %s \n",id1,menu.date.jour,menu.date.mois,menu.date.annee,al1,type);
fclose(f);


}




void
on_radiobuttonPd_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
 if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}
 
}


void
on_radiobuttonDIN_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=3;}
}


void
on_radiobuttonDEJ_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}
}


void
on_buttonMmenu_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Meilleur_menu;
GtkWidget *Choix;

Choix=lookup_widget(objet_graphique,"Choix");
  gtk_widget_destroy (Choix);
Meilleur_menu=lookup_widget(objet_graphique,"Meilleur_menu");
 Meilleur_menu = create_Meilleur_menu ();
  gtk_widget_show (Meilleur_menu);
}


void
on_buttonMj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour;
GtkWidget *Choix;
Choix=lookup_widget(objet_graphique,"Choix");
  gtk_widget_destroy (Choix);
Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
 Menu_du_jour = create_Menu_du_jour ();
  gtk_widget_show (Menu_du_jour);
}


void
on_buttonAj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
}


void
on_buttonAutre_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Autrechoix;
GtkWidget *Menu_du_jour;
Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
  gtk_widget_destroy (Menu_du_jour);
Autrechoix=lookup_widget(objet_graphique,"Autrechoix");
Autrechoix = create_Autrechoix ();
  gtk_widget_show (Autrechoix);
}


void
on_buttonAfficher_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Affichage;
GtkWidget *Menu_du_jour;

Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
  gtk_widget_destroy (Menu_du_jour);
Affichage=lookup_widget(objet_graphique,"Affichage");
Affichage = create_Affichage ();
gtk_widget_show (Affichage);

}


void
on_buttonSupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f;
FILE* f2;
Menu menu;
GtkWidget *id;
char id1[10];
f=fopen("menu.txt","r");
f2=fopen("tmp.txt","a+");
id=lookup_widget(objet_graphique,"entryIdet");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
if (f==NULL)
       return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id1,menu.id)!=0)
                   fprintf(f2,"%s %d %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
        }
    }
    fclose(f);
    fclose(f2);
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}


void
on_buttonModifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 FILE* f ;
 
Menu menu;

GtkWidget *id;
GtkWidget *Autre_choix;
GtkWidget *Menu_du_jour;
GtkWidget *Modif;
id=lookup_widget(objet_graphique,"entryIdet");

strcpy(id2,gtk_entry_get_text(GTK_ENTRY(id)));
    f=fopen("menu.txt","r");

        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id2,menu.id)==0)
                {
		  Autre_choix = lookup_widget(objet_graphique,"Autrechoix");
                   gtk_widget_destroy (Autre_choix); 
		Modif=lookup_widget(objet_graphique,"Modif");		  
		 Modif = create_Modif ();
                   gtk_widget_show (Modif);   
		   
		}
		else
                   {  Autre_choix=lookup_widget(objet_graphique,"Autre_choix");
                   gtk_widget_destroy (Autre_choix); 
		Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
		Menu_du_jour = create_Menu_du_jour ();
                    gtk_widget_show (Menu_du_jour);
		 
}	    
        }
    
    fclose(f);
}


void
on_buttonRecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f ;
Menu menu;
GtkWidget *id;
GtkWidget *output;
char id1[10];
char texte1[20];
 int rech=0;

id=lookup_widget(objet_graphique,"entryIdet");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
    f=fopen("menu.txt","r");
    if (f==NULL)
        return;
    else
    {
        while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
        {
                if (strcmp(id1,menu.id)==0)
		{
		        sprintf(texte1," aliment: %s\n",menu.aliment);
		        
                        output=lookup_widget(objet_graphique,"labelidet");
                        gtk_label_set_text(GTK_LABEL(output),texte1);
                        
			rech=1;
		}
        }
}
fclose(f);
    if (rech==0)
printf("Impossible de trouver ce menu");    

}


void
on_buttonOk_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE* f;
FILE* f2;
GtkWidget *ID;
GtkWidget *id;
GtkWidget *Al;
GtkWidget *Affichage;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
Menu menu;

char type[10]="PD";
int jour1;
int mois1;
int annee1;

char al1[10];

if (y==1)
strcpy(type,"PD");
else
if (y==2)
strcpy(type,"Dej");
else 
if (y==3)
strcpy(type,"Din");


jour=lookup_widget(objet_graphique,"jour1_menu");
mois=lookup_widget(objet_graphique,"mois1_menu");
annee=lookup_widget(objet_graphique,"annee1_menu");


Al=lookup_widget(objet_graphique,"entryalim");


strcpy(al1,gtk_entry_get_text(GTK_ENTRY(Al)));

menu.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
menu.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
menu.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

f=fopen("menu.txt","r");
f2=fopen("tmp.txt","a+");
while (fscanf(f,"%s %d %d %d %s %s ",menu.id,&menu.date.jour,&menu.date.mois,&menu.date.annee,menu.aliment,menu.type)!=EOF)
{
if (strcmp(id2,menu.id)!=0)
{
fprintf(f2,"%s %d %d %d %s %s \n",menu.id,menu.date.jour,menu.date.mois,menu.date.annee,menu.aliment,menu.type);
} 
else 
{
fprintf(f2,"%s %d %d %d %s %s \n",id2,menu.date.jour,menu.date.mois,menu.date.annee,al1,type);
}
}
    fclose(f2);
    fclose(f);
    
    remove("menu.txt");
    rename("tmp.txt","menu.txt");
}


void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=3;}
}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}





void
on_buttonAff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *label_meilleur;
label_meilleur = lookup_widget(objet_graphique, "Dejeu") ;


FILE* f;
Dechet d;
char ch[20];
char message[70];
int min=100;
char jour[30];



f=fopen("dechets.txt","r+");
if(f!=NULL)
{
while (fscanf(f,"%s %d %d\n",d.jour,&d.dejeuner,&d.dinner)!=EOF)
{
if (min >= d.dejeuner )
{
min = d.dejeuner;
strcpy(ch,"dejeuner");
strcpy(jour,d.jour);
}

if (min >= d.dinner)
{
min = d.dinner ;
strcpy(ch,"Dinner");
strcpy(jour,d.jour);
}

}
fclose(f);
sprintf(message,"Le meilleur menu est le : %s de %s",ch,jour);
gtk_label_set_text(GTK_LABEL(label_meilleur),message);
}

}







void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Menu_du_jour;
GtkWidget *Affichage;

Affichage=lookup_widget(objet_graphique,"Affichage");
gtk_widget_destroy(Affichage);
Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
 Menu_du_jour = create_Menu_du_jour ();
  gtk_widget_show (Menu_du_jour);
}


void
on_buttonshow_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Affichage;
GtkWidget *treeview1;
Menu menu;

Affichage = lookup_widget(objet_graphique,"buttonshow");
treeview1=lookup_widget(Affichage,"treeview1_menu");

Afficher(treeview1,"menu.txt");
}


void
on_buttonretourchoix_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *choix;
GtkWidget *Menu_du_jour;

 Menu_du_jour=lookup_widget(objet_graphique,"Menu_du_jour");
  gtk_widget_destroy (Menu_du_jour);
choix=lookup_widget(objet_graphique,"Choix");	
choix = create_Choix ();
  gtk_widget_show (choix);
}


void
on_buttonretourmodif_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Autre_choix;
GtkWidget *Modif;

Modif=lookup_widget(objet_graphique,"Modif");
gtk_widget_destroy (Modif); 
Autre_choix=lookup_widget(objet_graphique,"Autre_choix");
Autre_choix = create_Autrechoix ();
  gtk_widget_show (Autre_choix);
 
}


void
on_buttonretourMeilleur_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Meilleur_menu;
GtkWidget *Choix;

Meilleur_menu=lookup_widget(objet_graphique,"Meilleur_menu");
  gtk_widget_show (Meilleur_menu);
Choix=lookup_widget(objet_graphique,"Choix");	
Choix = create_Choix ();
  gtk_widget_show (Choix);
}



void
on_treeview1_menu_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *id;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* aliment;
	gchar* type;
	Menu menu;
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&jour,2,&mois,3,&annee,4,&aliment,5,&type,6,-1);
strcpy(menu.id,id);
strcpy(menu.date.jour,jour);
strcpy(menu.date.mois,mois);
strcpy(menu.date.annee,annee);
strcpy(menu.date.annee,annee);
strcpy(menu.aliment,aliment);
strcpy(menu.type,type);


Afficher(treeview,"menu.txt");
}
}


void
on_button1_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_Choix();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"page_accueil");
	gtk_widget_destroy(window);
}




void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window22;
window22=create_window2();
gtk_widget_show (window22);

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window44;
window44=create_window4();
gtk_widget_show (window44);
}

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

FILE *f=NULL;
GtkWidget *nom,*prenom,*email,*cin,*nomu,*mot,*cmot,*window33;
char chnom[20];
char chprenom[20];
char chemail[20];
int icin;
char chnomu[20];
char chmot[20];
char chcmot[20];
nom = lookup_widget (button, "entry1");
prenom = lookup_widget (button, "entry2");
email = lookup_widget (button, "entry3");
cin = lookup_widget (button, "entry4");
nomu=lookup_widget (button, "entry5");
mot = lookup_widget (button, "entry6");
cmot = lookup_widget (button, "entry7");
strcpy(chnom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(chprenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(chemail, gtk_entry_get_text(GTK_ENTRY(email)));
icin=gtk_entry_get_text(GTK_ENTRY(cin));
strcpy(chnomu, gtk_entry_get_text(GTK_ENTRY(nomu)));
strcpy(chmot, gtk_entry_get_text(GTK_ENTRY(mot)));
strcpy(chcmot, gtk_entry_get_text(GTK_ENTRY(cmot)));
//ouvrir le fichier 
f=fopen("utilisateur.txt","a+");
if (f!=NULL)
{
//ecrire dans le fichier
fprintf (f,"%s \n %s \n %s \n %d \n %s \n %s\n \n\n\n",chnom,chprenom,chemail,icin,chnomu,chmot);
fclose(f);
}
else
printf ("\n Not found");

window33=create_window3();
gtk_widget_show (window33);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window44;
window44=create_window4();
gtk_widget_show (window44);
}

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username,*password,*window55;
char user[20];
char pasw[20];
int trouve;
username = lookup_widget (button, "entry8");
password = lookup_widget (button, "entry9");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=(verif(user,pasw));

if(trouve==1)
{
window55=create_window5();
gtk_widget_show (window55);
}

}



void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{	int typ;
  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
  {typ=1;type(typ);
  }
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{	int typ;
  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
  {typ=2;type(typ);
  }
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{	int typ;
  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
  {typ=3;type(typ);
  }
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{	int typ;
  if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
  {typ=4;type(typ);
  }
}



void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *button6;
GtkWidget *treeview1;
button6=create_window7();
gtk_widget_show(button6);
treeview1=lookup_widget(button6,"treeview1");
afficher_temperature(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* jour;
	gchar* heure;
	gchar* num;
	gchar* val;
	temperature p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path)){


	gtk_tree_model_get (GTK_LIST_STORE(model), &iter , 0 ,&jour,1 ,&heure, 2 ,&num, 3 ,&val ,-1);
	strcpy(p.jour,jour);
	strcpy(p.heure,heure);
	strcpy(p.num,num);
	strcpy(p.val,val);
	afficher_temperature(treeview);
	}
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window44;
window44=create_window8();
gtk_widget_show (window44);
}



void
on_button8_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *button6;
GtkWidget *treeview1;
GtkWidget *button8;
temperature p;
GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
GtkWidget *val;
jour=lookup_widget(objet_graphique,"jour");
heure=lookup_widget(objet_graphique,"heure");
num=lookup_widget(objet_graphique,"num");
val=lookup_widget(objet_graphique,"val");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
p.heure=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(heure));
p.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(num));
p.val=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));

button8=create_window7();
gtk_widget_show(button8);
treeview1=lookup_widget(button8,"treeview1");


	FILE *f;
	f=fopen("temperature.txt","a+");
	if (f!=NULL){

	fprintf(f,"%d %d %d %d \n",p.jour,p.heure,p.num,p.val);
	
	}
fclose(f);
afficher_temperature(treeview1);
}//affiche

void
on_treeview2_row_activated             (GtkTreeView     *treeview2,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show(button);
FILE* f;
FILE* f2;



gtk_widget_show(button);

GtkWidget *treeview1;


GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
char jour1[20],heure1[20],num1[20],a[10],b[10],c[10],d[10];
f=fopen("temperature.txt","r");
f2=fopen("tmp.txt","w");
jour=lookup_widget(button,"jour");
heure=lookup_widget(button,"heure");
num=lookup_widget(button,"num");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(jour)));
strcpy(heure1,gtk_entry_get_text(GTK_ENTRY(heure)));
strcpy(num1,gtk_entry_get_text(GTK_ENTRY(num)));


       




f=fopen("temperature.txt","r");
f2=fopen("tmp.txt","w");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {
                if (strcmp(jour1,a)!=0||strcmp(heure1,b)!=0||strcmp(num1,c)!=0)
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);
       }
        
    fclose(f);
    fclose(f2);
    remove("temperature.txt");
    rename("tmp.txt","temperature.txt");

button=create_window7();
gtk_widget_show(button);
treeview1=lookup_widget(button,"treeview1");

afficher_temperature(treeview1);


}

void
on_suprime_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window47;
window47=create_window11();
gtk_widget_show (window47);
}





void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window47;
window47=create_window12();
gtk_widget_show (window47);
}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window47;
window47=create_window13();
gtk_widget_show (window47);
}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget       *button0;
GtkWidget *treeview4;
FILE* f;
FILE* f2;

char a[10],b[10],c[10],d[10];
int x;

f=fopen("temperature.txt","r");
f2=fopen("sta.txt","a+");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {

             x==d;
                if ((x>53)==1||(x<51))
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);

       }
        
    fclose(f);
    fclose(f2);





button0=create_window15();
gtk_widget_show(button0);
treeview4=lookup_widget(button0,"treeview4");


	//fonction statistique


afficher_temperature3(treeview4);
}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

gtk_widget_show(button);
FILE* f;
FILE* f2;
FILE* f3;
GtkWidget *treeview1;
GtkWidget *button00;
GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
char jour1[20],heure1[20],num1[20],a[10],b[10],c[10],d[10];
 remove("rech.txt");
jour=lookup_widget(button,"jour");
heure=lookup_widget(button,"heure");
num=lookup_widget(button,"num");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(jour)));
strcpy(heure1,gtk_entry_get_text(GTK_ENTRY(heure)));
strcpy(num1,gtk_entry_get_text(GTK_ENTRY(num)));


       




f=fopen("temperature.txt","r");
f2=fopen("rech.txt","w");
f3=fopen("eur.txt","w");

  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
{
        if (strcmp(jour1,a)!=0||strcmp(heure1,b)!=0||strcmp(num1,c)!=0)
                
				
                   fprintf(f3,"%s %s %s %s\n",a,b,c,d);
else fprintf(f2,"%s %s %s %s\n",a,b,c,d);
       }
        
    fclose(f);
    fclose(f2);
    fclose(f3);

	//fonction rechercher


button=create_window7();
gtk_widget_show(button);
treeview1=lookup_widget(button,"treeview1");

afficher_temperature4(treeview1);



}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)

{

GtkWidget *treeview1;

GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
GtkWidget *val;
GtkWidget *jour1;
GtkWidget *heure1;
GtkWidget *num1;
GtkWidget *val1;

char jour2[20],heure2[20],num2[20],a[10],b[10],c[10],d[10],jour3[20],heure3[20],num3[20],val3[20];

jour=lookup_widget(button,"jour");
heure=lookup_widget(button,"heure");
num=lookup_widget(button,"num");

strcpy(jour2,gtk_entry_get_text(GTK_ENTRY(jour)));
strcpy(heure2,gtk_entry_get_text(GTK_ENTRY(heure)));
strcpy(num2,gtk_entry_get_text(GTK_ENTRY(num)));



jour1=lookup_widget(button,"jour1");
heure1=lookup_widget(button,"heure1");
num1=lookup_widget(button,"num1");
val1=lookup_widget(button,"val1");
strcpy(jour3,gtk_entry_get_text(GTK_ENTRY(jour1)));
strcpy(heure3,gtk_entry_get_text(GTK_ENTRY(heure1)));
strcpy(num3,gtk_entry_get_text(GTK_ENTRY(num1)));
strcpy(val3,gtk_entry_get_text(GTK_ENTRY(val1)));




FILE* f=NULL;
FILE* f2;

f=fopen("temperature.txt","r");
f2=fopen("tmp.txt","w");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {
                if (strcmp(jour2,a)!=0||strcmp(heure2,b)!=0||strcmp(num2,c)!=0)
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);
                   else
                   fprintf(f2,"%s %s %s %s\n",jour3,heure3,num3,val3);}
        
    fclose(f);
    fclose(f2);
    remove("temperature.txt");
    rename("tmp.txt","temperature.txt");


button=create_window7();
gtk_widget_show(button);
treeview1=lookup_widget(button,"treeview1");


	//fonction modifier(jour,jour1)...

afficher_temperature(treeview1);

}


void
on_treeview3_row_activated             (GtkTreeView     *treeview3,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* jour;
	gchar* heure;
	gchar* num;
	gchar* val;
	temperature p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview3);

	if (gtk_tree_model_get_iter(model, &iter , path)){


	gtk_tree_model_get (GTK_LIST_STORE(model), &iter , 0 ,&jour,1 ,&heure, 2 ,&num, 3 ,&val ,-1);
	strcpy(p.jour,jour);
	strcpy(p.heure,heure);
	strcpy(p.num,num);
	strcpy(p.val,val);
	afficher_temperature3(treeview3);
	}
}

void
on_treeview4_row_activated             (GtkTreeView     *treeview4,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* jour;
	gchar* heure;
	gchar* num;
	gchar* val;
	temperature p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview4);

	if (gtk_tree_model_get_iter(model, &iter , path)){


	gtk_tree_model_get (GTK_LIST_STORE(model), &iter , 0 ,&jour,1 ,&heure, 2 ,&num, 3 ,&val ,-1);
	strcpy(p.jour,jour);
	strcpy(p.heure,heure);
	strcpy(p.num,num);
	strcpy(p.val,val);
	afficher_temperature3(treeview4);
	}
}


void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window2();
gtk_widget_show (window);
}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}





void
on_button26_login_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_window1();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"Login");
	gtk_widget_destroy(window);
}


void
on_button26_menu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_page_accueil();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"Choix");
	gtk_widget_destroy(window);
}


void
on_button27_reclamation_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_page_accueil();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"reclamation");
	gtk_widget_destroy(window);
}


void
on_logout_capteur_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_window1();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"window5");
	gtk_widget_destroy(window);
}


void
on_button29_capteur_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_Login();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"window1");
	gtk_widget_destroy(window);
}


void
on_button2_login_pressed               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry;
  entry=lookup_widget(button,"entry2_login");
  gtk_entry_set_visibility (GTK_ENTRY (entry), TRUE);
  return FALSE;
}


void
on_button2_login_released              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *entry;
  entry=lookup_widget(button,"entry2_login");
  gtk_entry_set_visibility (GTK_ENTRY (entry), FALSE);
  return FALSE;
}


void
on_button31_accueil_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window16;
	window16=create_window16();
	gtk_widget_show(window16);

	GtkWidget *treeview;
	treeview=lookup_widget(window16,"treeview5_tableau");
	Afficher_alert_stock(treeview);
			
	GtkWidget *label_meilleur;
label_meilleur = lookup_widget(window16, "label94_tableau") ;


FILE* f;
Dechet d2;
char ch2[20];
char message[70];
int min=100;
char jour[30];



f=fopen("dechets.txt","r+");
if(f!=NULL)
{
while (fscanf(f,"%s %d %d\n",d2.jour,&d2.dejeuner,&d2.dinner)!=EOF)
{
if (min >= d2.dejeuner )
{
min = d2.dejeuner;
strcpy(ch2,"dejeuner");
strcpy(jour,d2.jour);
}

if (min >= d2.dinner)
{
min = d2.dinner ;
strcpy(ch2,"Dinner");
strcpy(jour,d2.jour);
}

}
fclose(f);
sprintf(message," %s de %s",ch2,jour);
gtk_label_set_text(GTK_LABEL(label_meilleur),message);
}
GtkWidget*nb ,*l;
char ch[40];
int k;
k=service_reclamation();
l=lookup_widget(window16,"label92_tableau");
if (k==1)
{sprintf(ch,"hebergement");}
if (k==2)
{sprintf(ch,"restauration");}
gtk_label_set_text(GTK_LABEL(l),ch);
GtkWidget       *button0;
GtkWidget *treeview4;
FILE* f2;

char a[10],b[10],c[10],d[10];
int x;

f=fopen("temperature.txt","r");
f2=fopen("sta.txt","a+");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {

             x==d;
                if ((x>53)==1||(x<51))
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);

       }
        
    fclose(f);
    fclose(f2);




treeview4=lookup_widget(window16,"treeview6_tableau");


	//fonction statistique


afficher_temperature3(treeview4);
}


void
on_button27_tableau_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *NB2,*l;
GdkColor color;	
 char ch[40];
 NB2 =lookup_widget(button, "NB2" );
 int k=NBRE2();
 l=lookup_widget(button,"label85_tableau");
 sprintf(ch,"Le nombre de level2 est %d",k);
 gtk_label_set_text(GTK_LABEL(l),ch);

 gdk_color_parse("blue",&color);
 gtk_widget_modify_fg(l,GTK_STATE_NORMAL,&color);
}


void
on_button28_tableau_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GdkColor color;
GtkWidget *NB1,*l;
int k;
	
 char ch[40];
 NB1 =lookup_widget(button, "NB1" );
 k=NBRE1();

 l=lookup_widget(button,"label84_tableau");
 
sprintf(ch,"Le nombre de level1 est %d",k);
 gtk_label_set_text(GTK_LABEL(l),ch); 

 gdk_color_parse("red",&color);
 gtk_widget_modify_fg(l,GTK_STATE_NORMAL,&color);
}
void on_button29_tableau_clicked(GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *treeview;
	treeview=lookup_widget(button,"treeview5_tableau");
	Afficher_alert_stock(treeview);
}


void
on_button30_tableau_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget       *button0;
GtkWidget *treeview4;
FILE* f;
FILE* f2;

char a[10],b[10],c[10],d[10];
int x;

f=fopen("temperature.txt","r");
f2=fopen("sta.txt","a+");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {

             x==d;
                if ((x>53)==1||(x<51))
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);

       }
        
    fclose(f);
    fclose(f2);



treeview4=lookup_widget(button,"treeview6_tableau");


	//fonction statistique


afficher_temperature3(treeview4);
}


void
on_button265_accueil_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget* window1;
	window1=create_window1();
	gtk_widget_show(window1);
	GtkWidget* window;
	window=lookup_widget(button,"Page_accueil");
	gtk_widget_destroy(window);
}

