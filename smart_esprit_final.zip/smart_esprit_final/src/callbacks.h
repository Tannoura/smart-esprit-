#include <gtk/gtk.h>


typedef struct 
{

int mois ;
int jour ;
int annee;
}Date;
typedef struct stockage
{
char id[20];
char nom[20];
char type [20];
int quantite ;
Date date_achat;
Date date_expiration;
char quality [20];
int quantite_restante;
}stockage ;

void
on_Add_stock_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modify_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_add_ajout_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_ajout_stock_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_modifier_stock_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_modifier_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_stock2_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_supprimer_stock_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_stock_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualiser_stock2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Alert_stock_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualiser_stock3_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_stock10_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherche_stock_clicked             (GtkButton       *button,
                                        gpointer         user_data);
void
on_button1_login_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_addReturn_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_SUBMIT_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_delete_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonDELETE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_update_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonUPD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonADD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonUPDATE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonDLT_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonaffiche_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_buttonDELETE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonNBRE_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_returnb_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_NB2_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_NB1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);





void
on_buttonrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttoncheck_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_returnrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_alert_stock_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_affichage_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_add_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_okk_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_returnadd_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_sup_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_returnsup_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modf_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button_returnmodif_clicked          (GtkButton       *button,
                                        gpointer         user_data);




void
on_button_aff_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_servicereclame_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_service_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_resultat_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton  *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_reclamation_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_logout_accueil_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_reclamation_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_etudiant_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_stock_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_boutonAjouter_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonPd_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDIN_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDEJ_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonModifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonMmenu_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonMj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAj_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAutre_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAfficher_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonRecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonOk_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAff_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonshow_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourchoix_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourmodif_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourMeilleur_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_menu_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_accueil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
                                    

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_suprime_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_suprime_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_reclamation_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_reclamation_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button26_login_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button26_menu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27_reclamation_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_logout_capteur_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_capteur_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_login_pressed               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_login_released              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_accueil_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27_tableau_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_tableau_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_tableau_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_tableau_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button265_accueil_clicked           (GtkButton       *button,
                                        gpointer         user_data);
