////////////////////////////////////////////////////////////////////////////////
                                //bibliotheque


#include <gtk/gtk.h>
#include <string.h>


////////////////////////////////////////////////////////////////////////////////
                                //structure

typedef struct
{
  char firstname [100];
  char lastname [100];
  char cin [10];
  char level [200];
  char phone [20];
  char adress [100];
  char password [20];
} etudiant;
////////////////////////////////////////////////////////////////////////////////
                                //fonctions
void add_etudiant (etudiant e);
void aff_etudiant (GtkWidget* list,char ch[]);
void upd_etudiant (etudiant e1);
int del_etudiant (char cin []);
int check_etudiant (char cin []);
int NBRE1 ();
int NBRE2 ();

