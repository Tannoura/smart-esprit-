#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include<stdio.h>
#include<string.h>

int verif(char log[],char pw[])
{
FILE *f=NULL;
int trouve=-1;
char ch1[20];
char ch2[20];
char em[20];
int cin;
char ch3[20];
char ch4[20];
char ch5[20];
f=fopen("utilisateur.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %d %s %s %s\n",ch1,ch2,em,&cin,ch3,ch4,ch5)!=EOF)
{
if ((strcmp(ch3,log)==0)&&(strcmp(ch4,pw)==0))
trouve=1;
}
fclose(f);
}
return trouve;
}

void type(int typ)
{
	GtkWidget *window1,*window2,*window3,*window4;
if (typ==1)
{
window1=create_window7();
gtk_widget_show (window1);
}
if (typ==2)
{
window2=create_window8();
gtk_widget_show (window2);
}
if (typ==3)
{
window3=create_window11();
gtk_widget_show (window3);
}
if(typ==4)
{
window4=create_window10();
gtk_widget_show (window4);
}
}
