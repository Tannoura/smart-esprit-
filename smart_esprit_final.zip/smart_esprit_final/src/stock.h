#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
void ajout_stock(stockage stock);


void Modifier_Stock(stockage st);
void Supprimer_Stock(char id[20]);
void Afficher_alert_stock(GtkWidget *liste);
enum{
	ID,
	PRODUIT,
	TYPE,
	QUANTITE,
	QUALITE,
	DATE1,
	DATE2,
	QUANTITE_RESTANT,
	COLUMNS,

};
void reChercher_Stock(char id[20]);
