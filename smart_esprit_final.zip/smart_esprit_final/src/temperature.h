#include<gtk/gtk.h>
typedef struct 
  {
	int jour;
	int heure;
	int num;
	int  val;
  }temperature;


void afficher_temperature(GtkWidget *liste);
void afficher_temperature2(GtkWidget *liste);
void afficher_temperature4(GtkWidget *liste);
void afficher_temperature3(GtkWidget *liste);
void supprimer_temperature(temperature p);
void ajouter_temperature(temperature p);

