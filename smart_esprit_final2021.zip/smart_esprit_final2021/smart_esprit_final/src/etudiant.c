/////////////////////////////////////////////////////////////////////////////////
                                 //Bibliotheque
/////////////////////////////////////////////////////////////////////////////////


#include <string.h>
#include "etudiant.h"
#include <stdio.h>

enum
{
CIN,FIRSTNAME,LASTNAME,ADRESS,PHONE,LEVEL,PASSWORD,COLUMNS
};

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
                           
                               //fonction ajouter


void add_etudiant (etudiant e){
    FILE *f=fopen("db_etudiant.txt", "a+");
    fprintf(f,"%s %s %s %s %s %s %s \n" ,e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password);
    fclose(f);
}
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
                               //fonction supprimer

int del_etudiant (char cin [10])
{
    etudiant e ;
    FILE *f, *fcpy;

     f = fopen ("db_etudiant.txt","a+");
     fcpy = fopen ("db_etudiantcpy.txt","a+");
     while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){ 
      if (strcmp(cin,e.cin) != 0){
       fprintf (fcpy,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password);
      }
    }
 
  fclose(f);
  fclose(fcpy);
 
 remove("db_etudiant.txt");
  rename("db_etudiantcpy.txt","db_etudiant.txt");
   
  return 1 ;
}
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////

                          //fonction modifier

void upd_etudiant (etudiant e1){
    etudiant e ;
    FILE *f, *fcpy;

 f = fopen ("db_etudiant.txt","a+");
 fcpy = fopen ("db_etudiantcpy.txt","a+");
      while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){ 
      if (strcmp(e1.cin , e.cin) == 0){ 
        fprintf (fcpy,"%s %s %s %s %s %s %s \n" ,e1.cin,e1.firstname,e1.lastname,e1.adress,e1.phone,e1.level,e1.password);
      }
      else{
        fprintf(fcpy,"%s %s %s %s %s %s %s \n" ,e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password); 
 }
  }
  
  fclose(f);
  fclose(fcpy);
  remove("db_etudiant.txt");
  rename("db_etudiantcpy.txt","db_etudiant.txt");
  

}
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
                             //fonction recherche

int check_etudiant (char cin []){
   etudiant e;
   FILE *f ;
   int R = 0;
  
 f = fopen ("db_etudiant.txt","a+");
  while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){ 
  if (strcmp(e.cin ,cin)){
   R=1;
   return R;
}
} 
   fclose(f);
   return R;
}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
                              //fonction afficher
 


void aff_etudiant (GtkWidget* list,char ch[]){
  GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;

	GtkTreeIter iter;

	GtkListStore *store;
  etudiant e ;
store = NULL;

  FILE *f;
  store = gtk_tree_view_get_model(list);

  if (store==NULL)
  {
    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" CIN",renderer,"text",CIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" FIRSTNAME",renderer,"text",FIRSTNAME,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" LASTNAME",renderer,"text",LASTNAME,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" ADRESS",renderer,"text",ADRESS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" PHONE",renderer,"text",PHONE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" LEVEL",renderer,"text",LEVEL,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

    renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes(" PASSWORD",renderer,"text",PASSWORD,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

    store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

    f = fopen(ch,"r");

    if (f==NULL)
    {
      return;
    }
    else{
      f = fopen(ch,"a+");
      while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){
        gtk_list_store_append(store,&iter);
				gtk_list_store_set(store,&iter,CIN,e.cin,FIRSTNAME,e.firstname,LASTNAME,e.lastname,ADRESS,e.adress,PHONE,e.phone,LEVEL,e.level,PASSWORD,e.password, -1);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
		  g_object_unref(store);

    }
 
}
}


/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////


int NBRE1 ( )
 {

FILE*f;
int i=0;

etudiant e;

f=fopen("db_etudiant.txt","r+");
if (f!=NULL){

while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){ 

if (strcmp(e.level,"1")==0)
 {
   i++;
 }
   
} 
fclose(f);
return(i);
 }
}




int NBRE2 ( )

{

FILE*f;
int i=0;

etudiant e;

f=fopen("db_etudiant.txt","r+");
if (f!=NULL){

while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){ 


  if (strcmp(e.level,"2")==0)
     {
     i++;
}     

     




} 
fclose(f);
return (i);
 }
}





