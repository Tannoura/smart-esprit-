#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "etudiant.h"

char leveel[20];
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void
on_addReturn_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* addetudiant;
addetudiant = lookup_widget(objet_graphique, "Addetudiant");
gtk_widget_destroy(addetudiant);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);

}


void
on_SUBMIT_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* input;
etudiant e;

input = lookup_widget(objet_graphique, "entryCIN") ;
strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryFIRSTNAME") ;
strcpy(e.firstname,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryLASTNAME") ;
strcpy(e.lastname,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryADRESS") ;
strcpy(e.adress,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryPHONE") ;
strcpy(e.phone,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryEMAIL") ;
strcpy(e.level,gtk_entry_get_text(GTK_ENTRY(input)));

input = lookup_widget(objet_graphique, "entryPASSWORD") ;
strcpy(e.password,gtk_entry_get_text(GTK_ENTRY(input)));


add_etudiant(e);
}
void
on_delete_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget* affiche;
GtkWidget* DELETE;
DELETE = lookup_widget(objet_graphique, "DELETE");
gtk_widget_destroy(DELETE);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);

}



void
on_update_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* UPDATEetudiant;
UPDATEetudiant = lookup_widget(objet_graphique, "UPDATEetudiant");
gtk_widget_destroy(UPDATEetudiant);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);
}



void
on_buttonUPD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

  GtkWidget* input;
  etudiant e1;

  input = lookup_widget(objet_graphique, "entryCIN") ;
  strcpy(e1.cin,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryFIRSTNAME") ;
  strcpy(e1.firstname,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryLASTNAME") ;
  strcpy(e1.lastname,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryADRESS") ;
  strcpy(e1.adress,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryPHONE") ;
  strcpy(e1.phone,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryEMAIL") ;
  strcpy(e1.level,gtk_entry_get_text(GTK_ENTRY(input)));

  input = lookup_widget(objet_graphique, "entryPASSWORD") ;
  strcpy(e1.password,gtk_entry_get_text(GTK_ENTRY(input)));

  upd_etudiant(e1);
}



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_buttonADD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* addetudiant;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
addetudiant = lookup_widget(objet_graphique, "Addetudiant");
addetudiant = create_Addetudiant();
gtk_widget_show(addetudiant);

}


void
on_buttonUPDATE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* UPDATEetudiant;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
UPDATEetudiant = lookup_widget(objet_graphique, "UPDATEetudiant");
UPDATEetudiant = create_UPDATEetudiant();
gtk_widget_show(UPDATEetudiant);

}


void
on_buttonDLT_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* DELETE;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
DELETE = lookup_widget(objet_graphique, "DELETE");
DELETE = create_DELETE();
gtk_widget_show(DELETE);

}


void
on_buttonaffiche_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)


{
GtkWidget *affiche;
GtkWidget *treeview1;
affiche = lookup_widget(objet_graphique,"affiche");

treeview1 = lookup_widget(affiche,"treeview1");
aff_etudiant(treeview1,"db_etudiant.txt");
}







void
on_buttonDELETE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* input;
  char cin[50];
  input = lookup_widget(objet_graphique, "entryCIN") ;
  strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
  if (check_etudiant(cin)==1){
    del_etudiant(cin);
}

}


void
on_buttonNBRE_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget* affiche;
  GtkWidget* nbretudiant;
  affiche = lookup_widget(objet_graphique, "affiche");
  gtk_widget_destroy(affiche);
  nbretudiant = lookup_widget(objet_graphique, "nbretudiant");
  nbretudiant = create_nbretudiant();
  gtk_widget_show(nbretudiant);
}


void
on_returnb_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget* affiche;
  GtkWidget* nbretudiant;
  nbretudiant = lookup_widget(objet_graphique, "nbretudiant");
  gtk_widget_destroy(nbretudiant);
  affiche = lookup_widget(objet_graphique, "affiche");
  affiche = create_affiche();
  gtk_widget_show(affiche);
}






void
on_NB2_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NB2,*l;
GdkColor color;	
 char ch[40];
 NB2 =lookup_widget(objet, "NB2" );
 int k=NBRE2();
 l=lookup_widget(objet,"label36");
 sprintf(ch,"Le nombre de level2 est %d",k);
 gtk_label_set_text(GTK_LABEL(l),ch);

 gdk_color_parse("blue",&color);
 gtk_widget_modify_fg(l,GTK_STATE_NORMAL,&color);
}


void
on_NB1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{

GdkColor color;
GtkWidget *NB1,*l;
int k;
	
 char ch[40];
 NB1 =lookup_widget(objet, "NB1" );
 k=NBRE1();

 l=lookup_widget(objet,"label26");
 
sprintf(ch,"Le nombre de level1 est %d",k);
 gtk_label_set_text(GTK_LABEL(l),ch); 

 gdk_color_parse("red",&color);
 gtk_widget_modify_fg(l,GTK_STATE_NORMAL,&color);
}






void
on_buttonrecherche_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
char reche[20];
etudiant e;
GtkWidget* treeview2;
GtkWidget* input;
GtkWidget* recherche;


input = lookup_widget(objet_graphique, "entryrecherche") ;
strcpy(reche,gtk_entry_get_text(GTK_ENTRY(input)));
FILE *f=NULL;
FILE *f1=NULL;

f=fopen("db_etudiant.txt","r");
f1=fopen("db_etudiant1.txt","a+");

 while (fscanf(f,"%s %s %s %s %s %s %s \n",e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password)!=EOF){
  if (strcmp(reche,e.cin)==0){
       fprintf (f1,"%s %s %s %s %s %s %s \n" ,e.cin,e.firstname,e.lastname,e.adress,e.phone,e.level,e.password);
      
 
}
}
fclose(f);
fclose(f1);
recherche = lookup_widget(objet_graphique,"recherche");
treeview2 = lookup_widget(recherche,"treeview2");
aff_etudiant(treeview2,"db_etudiant1.txt");   
remove("db_etudiant1.txt");

}


void
on_buttoncheck_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* recherche;
affiche = lookup_widget(objet_graphique, "affiche");
gtk_widget_destroy(affiche);
recherche = lookup_widget(objet_graphique, "recherche");
recherche = create_recherche();
gtk_widget_show(recherche);

}


void
on_returnrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* affiche;
GtkWidget* recherche;
recherche = lookup_widget(objet_graphique, "recherche");
gtk_widget_destroy(recherche);
affiche = lookup_widget(objet_graphique, "affiche");
affiche = create_affiche();
gtk_widget_show(affiche);
}

