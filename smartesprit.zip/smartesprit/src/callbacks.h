#include <gtk/gtk.h>


void
on_addReturn_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_SUBMIT_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_delete_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonDELETE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_update_return_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonUPD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonADD_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonUPDATE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonDLT_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonaffiche_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_buttonDELETE_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonNBRE_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_returnb_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_NB2_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_NB1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);





void
on_buttonrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttoncheck_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_returnrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
